  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; BloodBank & Donor Management System 2017</p>
        </div>
        <!-- /.container -->
    </footer>